#import "ViewController.h"
#import <XLsn0wKit_objc.h>

#define ABColor(R, G, B, Alpha) [UIColor colorWithRed:(R)/255.0 green:(G)/255.0 blue:(B)/255.0 alpha:(Alpha)]
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define LINECOLOR [UIColor colorWithWhite:0.8 alpha:0.5]
#define ABButtonMargin 10.0

@interface ViewController () <UITextFieldDelegate>

@property (nonatomic, strong) UIButton *abBtn;

@property (nonatomic, strong) XLsn0wCountTimeButton *countTimeButton;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _countTimeButton = [XLsn0wCountTimeButton buttonWithType:UIButtonTypeCustom];
    _countTimeButton.frame = CGRectMake(81, 400, 150, 60);
    [_countTimeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    _countTimeButton.backgroundColor = [UIColor blueColor];
    [self.view addSubview:_countTimeButton];
    
    
    [_countTimeButton countDownButtonHandler:^(XLsn0wCountTimeButton*sender, NSInteger tag) {
        sender.enabled = NO;
        
        [sender startCountDownWithSecond:60];
        
        [sender countDownChanging:^NSString *(XLsn0wCountTimeButton *countDownButton,NSUInteger second) {
            NSString *title = [NSString stringWithFormat:@"剩余%zd秒",second];
            return title;
        }];
        [sender countDownFinished:^NSString *(XLsn0wCountTimeButton *countDownButton, NSUInteger second) {
            countDownButton.enabled = YES;
            return @"点击重新获取";
            
        }];
        
    }];

    
    /// 创建按钮
    [self setupBtn];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setupBtn {
    for (int i = 0; i < 3; i++) {
        _abBtn = [[UIButton alloc] init];
        [_abBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        _abBtn.backgroundColor = [UIColor grayColor];
        _abBtn.frame = CGRectMake([UIScreen mainScreen].bounds.size.width/3*i + 20, 200, [UIScreen mainScreen].bounds.size.width/4, [UIScreen mainScreen].bounds.size.width/4);
        _abBtn.tag = i;
        switch (i) {
            case 0:
            {
                [_abBtn setTitle:@"30" forState:(UIControlStateNormal)];
                //                abBtn.enabled = NO;
            }
                break;
            case 1:
            {
                [_abBtn setTitle:@"50" forState:(UIControlStateNormal)];
                
            }
                break;
            case 2:
            {
                [_abBtn setTitle:@"100" forState:(UIControlStateNormal)];
                
            }
                break;
                
            default:
                break;
        }
        
        int col = i % 3;
//        _abBtn.x = col * (_abBtn.width + ABButtonMargin)+20;
        int row = i / 3;
//        _abBtn.y = row * (_abBtn.height + ABButtonMargin)+180;
        [self.view addSubview:_abBtn];
        [_abBtn addTarget:self action:@selector(chargePhone:) forControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)chargePhone:(UIButton*)button{
    if(_abBtn != button) {
        //本次点击的按钮设为红色
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        button.backgroundColor = [UIColor blueColor];
        
        //将上次点击过的按钮设为黑色
        [_abBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _abBtn.backgroundColor = [UIColor grayColor];
    }
        _abBtn = button;
    
    
    NSLog(@"%@", button.titleLabel.text);
}

@end
